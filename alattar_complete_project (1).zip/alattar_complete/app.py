import os
import secrets
from functools import wraps
from urllib.parse import quote
from flask import Flask, render_template, request, redirect, url_for, session, flash, abort
import psycopg
from psycopg.rows import dict_row
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-only-change-this-before-deploying")
WHATSAPP_NUMBER = os.environ.get("WHATSAPP_NUMBER", "962781611698")
CATEGORIES = ["البهارات", "الأعشاب", "البقوليات", "المونة البلدية", "العطور", "الزيوت"]
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}

SEED_PRODUCTS = [
    ("فاصوليا", "البقوليات", 1.00, ""),
    ("عدس حب", "البقوليات", 1.00, ""),
    ("فريكة جنين", "المونة البلدية", 2.50, ""),
    ("حمص مكسيكي", "البقوليات", 1.50, ""),
    ("برغل", "المونة البلدية", 0.75, ""),
    ("برغل ناعم بلدي", "المونة البلدية", 1.00, ""),
    ("طحين قمح بلدي", "المونة البلدية", 1.00, ""),
    ("قمح بلدي", "المونة البلدية", 0.75, ""),
    ("شوفان", "البقوليات", 2.00, ""),
    ("نشا سعودي", "المونة البلدية", 1.00, ""),
    ("كربونة", "المونة البلدية", 1.00, ""),
    ("زعتر بلدي", "الأعشاب", 2.50, ""),
    ("زعتر ورق", "الأعشاب", 4.00, ""),
    ("قرفة خشب", "البهارات", 3.50, ""),
    ("قرفة سيجار", "البهارات", 6.00, ""),
    ("قهوة إكسترا", "البهارات", 6.00, ""),
    ("شاي ماتشا", "الأعشاب", 2.00, ""),
    ("زيت هيماني", "الزيوت", 0.00, "30 مل"),
    ("عطر جديد", "العطور", 0.00, "حدد الحجم والسعر من لوحة الأدمن"),
]

def db():
    url = os.environ.get("DATABASE_URL")
    if not url:
        raise RuntimeError("DATABASE_URL غير مضبوط. أضفه في إعدادات التشغيل.")
    return psycopg.connect(url, row_factory=dict_row)

def init_db():
    with db() as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id BIGSERIAL PRIMARY KEY,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            description TEXT DEFAULT '',
            price NUMERIC(10,2) NOT NULL DEFAULT 0,
            old_price NUMERIC(10,2),
            size TEXT DEFAULT '',
            stock INTEGER NOT NULL DEFAULT 0,
            image_url TEXT DEFAULT '',
            active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ DEFAULT NOW()
        )""")
        conn.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id BIGSERIAL PRIMARY KEY,
            customer_name TEXT NOT NULL,
            phone TEXT NOT NULL,
            address TEXT NOT NULL,
            notes TEXT DEFAULT '',
            items_json JSONB NOT NULL,
            total NUMERIC(10,2) NOT NULL,
            status TEXT NOT NULL DEFAULT 'جديد',
            created_at TIMESTAMPTZ DEFAULT NOW()
        )""")
        count = conn.execute("SELECT COUNT(*) AS n FROM products").fetchone()["n"]
        if count == 0:
            for name, category, price, size in SEED_PRODUCTS:
                conn.execute(
                    "INSERT INTO products(name, category, price, size, description) VALUES (%s,%s,%s,%s,%s)",
                    (name, category, price, size, "أضف الوصف والصورة والسعر من لوحة الأدمن" if price == 0 else "")
                )

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("admin"):
            return redirect(url_for("admin_login"))
        return fn(*args, **kwargs)
    return wrapper

def money(v):
    return float(v or 0)

@app.context_processor
def common():
    return {"categories": CATEGORIES, "cart_count": sum(session.get("cart", {}).values())}

@app.route("/")
def home():
    with db() as conn:
        products = conn.execute("SELECT * FROM products WHERE active=TRUE ORDER BY id DESC LIMIT 12").fetchall()
    return render_template("index.html", products=products)

@app.route("/products")
def products():
    category = request.args.get("category", "")
    with db() as conn:
        if category in CATEGORIES:
            rows = conn.execute("SELECT * FROM products WHERE active=TRUE AND category=%s ORDER BY id DESC", (category,)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM products WHERE active=TRUE ORDER BY id DESC").fetchall()
    return render_template("products.html", products=rows, selected=category)

@app.route("/product/<int:product_id>")
def product(product_id):
    with db() as conn:
        item = conn.execute("SELECT * FROM products WHERE id=%s AND active=TRUE", (product_id,)).fetchone()
    if not item: abort(404)
    return render_template("product.html", item=item)

@app.route("/cart")
def cart():
    cart_items = []
    total = 0
    ids = list(session.get("cart", {}).keys())
    if ids:
        with db() as conn:
            rows = conn.execute("SELECT * FROM products WHERE id = ANY(%s) AND active=TRUE", (ids,)).fetchall()
        for p in rows:
            qty = int(session["cart"].get(str(p["id"]), 0))
            price = money(p["price"])
            subtotal = price * qty
            total += subtotal
            cart_items.append({"product": p, "qty": qty, "subtotal": subtotal})
    return render_template("cart.html", cart_items=cart_items, total=total)

@app.post("/cart/add/<int:product_id>")
def add_cart(product_id):
    with db() as conn:
        p = conn.execute("SELECT id, price, active FROM products WHERE id=%s", (product_id,)).fetchone()
    if not p or not p["active"] or money(p["price"]) <= 0:
        flash("هذا المنتج غير متاح للطلب حاليًا.")
        return redirect(request.referrer or url_for("products"))
    cart = session.get("cart", {})
    key = str(product_id)
    cart[key] = int(cart.get(key, 0)) + max(1, int(request.form.get("qty", 1)))
    session["cart"] = cart
    flash("تمت إضافة المنتج إلى السلة.")
    return redirect(url_for("cart"))

@app.post("/cart/update")
def update_cart():
    cart = {}
    for key, value in request.form.items():
        if key.startswith("qty_"):
            try:
                qty = int(value)
                if qty > 0: cart[key[4:]] = min(qty, 99)
            except ValueError:
                pass
    session["cart"] = cart
    return redirect(url_for("cart"))

@app.route("/checkout", methods=["GET", "POST"])
def checkout():
    cart = session.get("cart", {})
    if not cart:
        flash("السلة فارغة.")
        return redirect(url_for("products"))
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        phone = request.form.get("phone", "").strip()
        address = request.form.get("address", "").strip()
        notes = request.form.get("notes", "").strip()
        if not all([name, phone, address]):
            flash("يرجى تعبئة الاسم ورقم الهاتف والعنوان.")
            return redirect(url_for("checkout"))
        items = []
        total = 0
        with db() as conn:
            for pid, qty in cart.items():
                p = conn.execute("SELECT * FROM products WHERE id=%s AND active=TRUE", (int(pid),)).fetchone()
                if p and money(p["price"]) > 0:
                    q = int(qty)
                    price = money(p["price"])
                    items.append({"name": p["name"], "size": p["size"], "qty": q, "price": price})
                    total += price * q
            if not items:
                flash("لا توجد منتجات متاحة في السلة.")
                return redirect(url_for("cart"))
            order = conn.execute("""
                INSERT INTO orders(customer_name, phone, address, notes, items_json, total)
                VALUES (%s,%s,%s,%s,%s,%s) RETURNING id
            """, (name, phone, address, notes, psycopg.types.json.Jsonb(items), total)).fetchone()
        lines = [f"طلب جديد رقم #{order['id']}", f"الاسم: {name}", f"الهاتف: {phone}", f"العنوان: {address}", "المنتجات:"]
        for it in items:
            lines.append(f"- {it['name']} {it['size']} × {it['qty']} = {it['price']*it['qty']:.2f} د.أ")
        lines += [f"المجموع: {total:.2f} د.أ", "التوصيل يبدأ من 1 دينار حسب المنطقة", f"ملاحظات: {notes or 'لا يوجد'}"]
        wa_url = "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + quote("\n".join(lines))
        session["cart"] = {}
        return render_template("order_success.html", wa_url=wa_url, order_id=order["id"])
    return render_template("checkout.html")

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        password = os.environ.get("ADMIN_PASSWORD", "")
        if password and secrets.compare_digest(request.form.get("password", ""), password):
            session["admin"] = True
            return redirect(url_for("admin"))
        flash("كلمة المرور غير صحيحة أو لم يتم ضبط ADMIN_PASSWORD.")
    return render_template("admin_login.html")

@app.get("/admin/logout")
def admin_logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/admin")
@admin_required
def admin():
    with db() as conn:
        products = conn.execute("SELECT * FROM products ORDER BY id DESC").fetchall()
        orders = conn.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 50").fetchall()
    return render_template("admin.html", products=products, orders=orders)

@app.route("/admin/product/save", methods=["POST"])
@admin_required
def save_product():
    pid = request.form.get("id", "").strip()
    name = request.form.get("name", "").strip()
    category = request.form.get("category", "")
    if not name or category not in CATEGORIES:
        flash("أدخل اسم المنتج واختر قسمًا صحيحًا.")
        return redirect(url_for("admin"))
    try:
        price = float(request.form.get("price", "0") or 0)
        old_price = request.form.get("old_price", "").strip()
        old_price = float(old_price) if old_price else None
        stock = int(request.form.get("stock", "0") or 0)
    except ValueError:
        flash("السعر أو المخزون غير صحيح.")
        return redirect(url_for("admin"))
    image_url = request.form.get("image_url", "").strip()
    upload = request.files.get("image")
    if upload and upload.filename:
        ext = upload.filename.rsplit(".", 1)[-1].lower()
        if ext not in ALLOWED_EXTENSIONS:
            flash("صيغة الصورة غير مدعومة.")
            return redirect(url_for("admin"))
        if os.environ.get("CLOUDINARY_URL"):
            import cloudinary
            import cloudinary.uploader
            result = cloudinary.uploader.upload(upload, folder="alattar")
            image_url = result.get("secure_url", image_url)
        else:
            flash("لرفع الصور بشكل دائم على Render، أعد إعداد Cloudinary ثم أضف رابط الصورة.")
    values = (name, category, request.form.get("description", "").strip(), price, old_price,
              request.form.get("size", "").strip(), stock, image_url, request.form.get("active") == "on")
    with db() as conn:
        if pid:
            conn.execute("""UPDATE products SET name=%s,category=%s,description=%s,price=%s,old_price=%s,
                         size=%s,stock=%s,image_url=%s,active=%s WHERE id=%s""", values + (int(pid),))
        else:
            conn.execute("""INSERT INTO products(name,category,description,price,old_price,size,stock,image_url,active)
                         VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""", values)
    flash("تم حفظ المنتج.")
    return redirect(url_for("admin"))

@app.post("/admin/product/delete/<int:pid>")
@admin_required
def delete_product(pid):
    with db() as conn:
        conn.execute("DELETE FROM products WHERE id=%s", (pid,))
    flash("تم حذف المنتج.")
    return redirect(url_for("admin"))

@app.post("/admin/order/status/<int:oid>")
@admin_required
def order_status(oid):
    status = request.form.get("status", "جديد")
    if status not in ["جديد", "قيد التجهيز", "تم الشحن", "مكتمل", "ملغي"]:
        abort(400)
    with db() as conn:
        conn.execute("UPDATE orders SET status=%s WHERE id=%s", (status, oid))
    return redirect(url_for("admin"))

@app.errorhandler(404)
def not_found(_):
    return render_template("404.html"), 404

if os.environ.get("DATABASE_URL"):
    try:
        init_db()
    except Exception as exc:
        print("Database initialization failed:", exc)
