# متجر العطّار

## التشغيل المحلي
1. ثبّت Python 3.11 أو أحدث.
2. افتح مجلد المشروع في VS Code.
3. أنشئ بيئة: `python -m venv venv`
4. فعّلها في PowerShell: `.\\venv\\Scripts\\Activate.ps1`
5. ثبّت الحزم: `python -m pip install -r requirements.txt`
6. أنشئ قاعدة PostgreSQL في Neon وانسخ رابط الاتصال إلى متغير `DATABASE_URL`.
7. اضبط `SECRET_KEY` و`ADMIN_PASSWORD` و`WHATSAPP_NUMBER`.
8. شغّل: `python -m flask --app app run --debug`

## إعدادات Render
- Build Command: `pip install -r requirements.txt`
- Start Command: `gunicorn app:app`
- أضف متغيرات البيئة `DATABASE_URL`, `SECRET_KEY`, `ADMIN_PASSWORD`, `WHATSAPP_NUMBER`.
- لا تنشئ خدمة Render جديدة إذا كان المطلوب تحديث الخدمة الحالية.
- أضف `CLOUDINARY_URL` حتى تُحفظ الصور بشكل دائم. لا تعتمد على تخزين الملفات المحلي في Render المجاني.

## ملاحظات
- أول تشغيل ينشئ الجداول ويضيف المنتجات الأساسية إذا كان جدول المنتجات فارغًا.
- أسعار زيت هيماني والعطر الافتراضي تبدأ بصفر، ويجب تحديد السعر والحجم من لوحة الأدمن قبل إتاحتها للشراء.
- هذا المشروع لا يستورد تلقائيًا بيانات SQLite القديمة.
- لا تشارك كلمات المرور أو روابط قواعد البيانات السرية في المحادثة أو GitHub.
